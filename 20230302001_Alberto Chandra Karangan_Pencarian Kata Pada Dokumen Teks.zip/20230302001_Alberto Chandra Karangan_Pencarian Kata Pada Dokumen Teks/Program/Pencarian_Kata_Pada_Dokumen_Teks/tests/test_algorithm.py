# File ini dapat digunakan untuk menulis unit test untuk algoritma pencarian.
# Contoh:
# import unittest
# from src.algorithm import cari_pola
#
# class TestAlgorithm(unittest.TestCase):
#     def test_pencarian_berhasil(self):
#         teks = "ababcab"
#         pola = "abc"
#         self.assertEqual(cari_pola(teks, pola, 101), [2])
#
# if __name__ == '__main__':
#     unittest.main()
