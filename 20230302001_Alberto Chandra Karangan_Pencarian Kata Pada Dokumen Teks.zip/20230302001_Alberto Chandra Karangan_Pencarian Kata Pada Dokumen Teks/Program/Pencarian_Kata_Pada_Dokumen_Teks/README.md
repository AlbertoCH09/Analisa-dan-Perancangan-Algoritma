# Proyek Implementasi Algoritma Rabin-Karp

## Deskripsi Singkat

Proyek ini merupakan studi dan implementasi Algoritma Rabin-Karp, salah satu metode _string matching_ yang efisien, untuk permasalahan pencarian kata dalam data teks. Dokumen ini berfungsi sebagai dokumentasi utama yang mencakup gambaran umum proyek, detail implementasi, serta panduan penggunaan aplikasi.

## Gambaran Umum Proyek

Dalam era digital saat ini, kebutuhan untuk mencari informasi spesifik dalam volume teks yang besar sangatlah krusial. Permasalahan pencarian string (kata atau frasa) dalam sebuah teks panjang menjadi tantangan komputasi yang memerlukan solusi cepat dan akurat. Proyek ini hadir untuk mengatasi tantangan tersebut dengan memanfaatkan Algoritma Rabin-Karp.

Tujuan utama proyek ini adalah:
1.  Mempelajari konsep dasar dan cara kerja Algoritma Rabin-Karp.
2.  Merancang dan membangun aplikasi antarmuka grafis (GUI) interaktif menggunakan Python untuk mengimplementasikan algoritma ini.
3.  Mendemonstrasikan penerapan algoritma dalam studi kasus pencarian kata pada teks sehari-hari, mendukung berbagai format file.
4.  Mengembangkan aplikasi GUI dengan fitur-fitur canggih seperti pencarian *real-time*, penggantian teks, dan ekspor hasil.
5.  Menghasilkan dokumentasi lengkap dalam format laporan akademik.

## Tentang Algoritma Rabin-Karp

Algoritma Rabin-Karp adalah algoritma _exact string matching_ yang secara cerdas memanfaatkan konsep *hashing* untuk menemukan pola dalam teks. Alih-alih membandingkan karakter demi karakter secara langsung, algoritma ini menghitung nilai hash untuk pola dan jendela teks. Teknik *rolling hash* memungkinkan pembaruan nilai hash jendela teks secara efisien dalam waktu konstan, sehingga mempercepat proses pencarian secara signifikan pada kasus rata-rata.

## Fitur Utama Aplikasi GUI (`main.py`)

Aplikasi GUI dirancang untuk memberikan pengalaman pengguna yang intuitif dan fungsionalitas yang kuat:

-   **Antarmuka Interaktif:** Desain modern dan futuristik dengan elemen Tkinter yang responsif.
-   **Pencarian Real-time:** Melakukan pencarian secara otomatis saat pengguna mengetik pola, dengan feedback instan.
-   **Muat dari File:** Mendukung pemuatan teks utama dari file `.txt`, `.pdf`, dan `.docx`.
-   **Riwayat Pencarian:** Menyimpan dan menampilkan riwayat pola pencarian sebelumnya untuk akses cepat.
-   **Opsi Case-Sensitive:** Pengguna dapat memilih apakah pencarian membedakan huruf besar atau kecil.
-   **Fungsi Ganti (Replace):** Kemampuan untuk mengganti pola yang ditemukan dengan teks lain, baik satu per satu ("Ganti") maupun semua sekaligus ("Ganti Semua").
-   **Navigasi Hasil:** Tombol "Sebelumnya" dan "Berikutnya" untuk berpindah antar semua kemunculan pola.
-   **Visualisasi Hasil:**
    -   Semua kemunculan pola disorot langsung di area teks utama.
    -   Kecocokan yang sedang aktif disorot dengan warna berbeda.
    -   Daftar semua kecocokan ditampilkan dalam kotak daftar (`Listbox`) beserta cuplikan baris dan lokasi (baris dan kolom).
-   **Ekspor Hasil:** Menyimpan ringkasan detail hasil pencarian ke dalam sebuah file teks (`.txt`).
-   **Status Bar Informatif:** Menampilkan jumlah total karakter dan kata dari teks utama secara real-time.

## Instalasi

Pastikan Anda memiliki Python 3 terinstal di sistem Anda.

Instal semua pustaka yang diperlukan dengan menjalankan perintah berikut:

```sh
pip install -r requirements.txt
```

## Cara Menjalankan Program

Pilih salah satu versi program yang ingin Anda jalankan.



### 1. Versi Antarmuka Grafis (GUI)

Aplikasi GUI menawarkan antarmuka yang interaktif dan kaya fitur untuk pencarian pola.

1.  Pastikan Anda telah menginstal Python 3 dan pustaka tambahan yang diperlukan (lihat bagian [Instalasi](#instalasi)). Pustaka Tkinter biasanya sudah termasuk dalam instalasi Python standar.
2.  Buka terminal atau _command prompt_.
3.  Navigasikan ke direktori `string-matching-rabin-karp` ini.
4.  Jalankan perintah berikut:
    ```sh
    python src/main.py
    ```
5.  Jendela aplikasi akan muncul. Berikut adalah cara menggunakan fitur-fitur utamanya:
    -   **Input Teks Utama:** Masukkan teks yang ingin dicari di area "Teks:". Anda juga bisa memuat teks dari file (`.txt`, `.pdf`, `.docx`) dengan mengklik tombol "Muat dari File" di sampingnya.
    -   **Input Pola Pencarian:** Masukkan pola (kata atau frasa) yang ingin Anda cari di kolom "Cari Pola:". Aplikasi akan melakukan pencarian secara *real-time* saat Anda mengetik. Riwayat pencarian sebelumnya juga tersedia melalui dropdown.
    -   **Opsi Case-Sensitive:** Centang kotak "Case-Sensitive" jika Anda ingin pencarian membedakan huruf besar dan kecil.
    -   **Tombol "Cari Pola":** Klik tombol ini untuk memulai pencarian manual atau menyegarkan hasil.
    -   **Navigasi Hasil:** Jika pola ditemukan, hasil akan disorot di teks utama. Gunakan tombol "< Sebelumnya" dan "Berikutnya >" untuk berpindah antar hasil. Daftar semua hasil juga akan muncul di kotak di bawah teks utama.
    -   **Fungsi Ganti:** Masukkan teks pengganti di kolom "Ganti dgn:".
        -   Klik "Ganti" untuk mengganti satu kecocokan yang sedang aktif.
        -   Klik "Ganti Semua" untuk mengganti semua kemunculan pola di dalam teks.
    -   **Tombol "Bersihkan":** Menghapus semua input dan hasil pencarian.
    -   **Tombol "Export Hasil":** Menyimpan ringkasan detail hasil pencarian ke dalam file teks.
    -   **Status Bar:** Di bagian bawah, Anda akan melihat jumlah total karakter dan kata dari teks utama.



## Struktur Folder

```
string-matching-rabin-karp/
│
├── PRP.md
├── TODO.md
├── requirements.txt

│
├── src/
│   
│   └── main.py
│
└── README.md
```