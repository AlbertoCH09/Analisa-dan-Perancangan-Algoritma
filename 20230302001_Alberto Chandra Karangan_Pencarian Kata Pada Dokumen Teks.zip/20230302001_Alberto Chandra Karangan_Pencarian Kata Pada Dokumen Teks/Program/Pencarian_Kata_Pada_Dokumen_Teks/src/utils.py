import os
from docx import Document
from pypdf import PdfReader

def read_file_content(file_path):
    """
    Membaca konten dari file yang diberikan, mendukung format .txt, .pdf, dan .docx.
    Mengembalikan tuple (konten, error)
    """
    _, file_extension = os.path.splitext(file_path)
    content = ""
    try:
        if file_extension.lower() == ".pdf":
            reader = PdfReader(file_path)
            for page in reader.pages:
                content += page.extract_text() or ""
        elif file_extension.lower() == ".docx":
            doc = Document(file_path)
            for para in doc.paragraphs:
                content += para.text + "\n"
        else: # Asumsikan .txt atau file teks biasa lainnya
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
    except Exception as e:
        return None, str(e) # Mengembalikan None untuk konten dan pesan error
    return content, None # Mengembalikan konten dan None untuk error
