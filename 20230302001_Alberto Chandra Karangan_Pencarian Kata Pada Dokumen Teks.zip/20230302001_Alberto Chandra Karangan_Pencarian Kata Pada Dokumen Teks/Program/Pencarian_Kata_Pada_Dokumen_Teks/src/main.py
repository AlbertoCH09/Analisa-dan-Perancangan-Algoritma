# Implementasi Antarmuka Grafis (GUI) untuk Algoritma Rabin-Karp

import tkinter as tk
from tkinter import ttk, font, filedialog
import os
import time

# Impor fungsi dari file terpisah
from algorithm import cari_pola
from utils import read_file_content

# ==============================================================================
# KELAS UTAMA UNTUK GUI
# ==============================================================================

class RabinKarpGUI:
    def __init__(self, root):
        """
        Inisialisasi aplikasi GUI Rabin-Karp.
        """
        self.root = root
        self.found_indices = []
        self.current_match_index = -1
        self.case_sensitive = tk.BooleanVar()
        self.search_history = []
        self.pattern_var = tk.StringVar()
        self.search_timer = None # Timer for real-time search
        self.search_duration = 0 # Duration of the last search
        
        self.setup_theme()
        self.setup_window()
        self.create_widgets()

    def setup_theme(self):
        """
        Mengatur skema warna, font, dan gaya untuk widget.
        """
        self.BG_COLOR = "#2B2B2B"
        self.FG_COLOR = "#03FA39"
        self.INPUT_BG_COLOR = "#3C3F41"
        self.ACCENT_COLOR = "#4A90E2"
        self.ACCENT_HOVER_COLOR = "#63A3ED"
        self.HIGHLIGHT_COLOR = "#F9A825"
        self.HIGHLIGHT_CURRENT_COLOR = "#D94821"

        self.default_font = font.Font(family="Segoe UI", size=11)
        self.title_font = font.Font(family="Segoe UI Semibold", size=16)

        style = ttk.Style(self.root)
        style.theme_use("clam")

        style.configure(".", background=self.BG_COLOR, foreground=self.FG_COLOR, font=self.default_font)
        style.configure("TLabel", background=self.BG_COLOR, foreground=self.FG_COLOR)
        style.configure("TFrame", background=self.BG_COLOR)
        style.configure("TEntry", fieldbackground=self.INPUT_BG_COLOR, foreground=self.FG_COLOR, borderwidth=0, insertcolor=self.FG_COLOR)
        style.configure("TCombobox", fieldbackground=self.INPUT_BG_COLOR, selectbackground=self.INPUT_BG_COLOR, selectforeground=self.FG_COLOR, foreground=self.FG_COLOR)
        
        style.configure("TButton", background=self.ACCENT_COLOR, foreground=self.FG_COLOR, borderwidth=0, font=("Segoe UI", 12, "bold"), padding=10)
        style.map("TButton", background=[("active", self.ACCENT_HOVER_COLOR)])
        
        style.configure("File.TButton", background="#555555", foreground=self.FG_COLOR, borderwidth=0, font=("Segoe UI", 9), padding=5)
        style.map("File.TButton", background=[("active", "#666666")])

        style.configure("Nav.TButton", background="#4A4A4A", foreground=self.FG_COLOR, font=("Segoe UI", 10))
        style.map("Nav.TButton", background=[("active", "#5A5A5A")])

        style.configure("TCheckbutton", background=self.BG_COLOR, foreground=self.FG_COLOR)
        style.map("TCheckbutton", background=[("active", self.BG_COLOR)],
                  indicatorcolor=[("selected", self.ACCENT_COLOR), ("!selected", self.INPUT_BG_COLOR)])
        style.configure("Accent.TButton", background=self.HIGHLIGHT_COLOR, foreground="#000000", font=("Segoe UI", 10, "bold"))
        style.map("Accent.TButton", background=[("active", self.HIGHLIGHT_CURRENT_COLOR)])
        style.configure("Sash", background="#333333", bordercolor="#444444")

    def setup_window(self):
        """
        Mengatur properti jendela utama.
        """
        self.root.title("Rabin-Karp String Search")
        self.root.geometry("800x600")
        self.root.configure(bg=self.BG_COLOR)
        self.root.minsize(600, 500)

    def create_widgets(self):
        """
        Membuat dan menata semua widget di dalam jendela aplikasi.
        """
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=(20, 0))
        
        title_label = ttk.Label(main_frame, text="Rabin-Karp Pattern Search", font=self.title_font)
        title_label.pack(pady=(0, 15))

        input_grid = ttk.Frame(main_frame)
        input_grid.pack(fill=tk.X, pady=(0, 5))
        input_grid.columnconfigure(1, weight=1)

        text_label_frame = ttk.Frame(input_grid)
        text_label_frame.grid(row=0, column=0, sticky="nw", padx=(0, 10))
        ttk.Label(text_label_frame, text="Teks:", width=10).pack(side="left")
        load_text_button = ttk.Button(text_label_frame, text="Muat dari File", style="File.TButton", command=self.load_text_from_file)
        load_text_button.pack(side="left", padx=(5,0))

        self.text_input = tk.Text(input_grid, height=8, width=80,
                                  bg=self.INPUT_BG_COLOR, fg=self.FG_COLOR,
                                  padx=10, pady=10, relief="flat",
                                  font=self.default_font, insertbackground=self.FG_COLOR, wrap="word")
        self.text_input.grid(row=0, column=1, sticky="nsew", rowspan=3)
        self.text_input.bind("<KeyRelease>", self.schedule_search)

        ttk.Label(input_grid, text="Cari Pola:").grid(row=1, column=0, sticky="w", padx=(0, 10), pady=(5,0))
        self.pattern_input = ttk.Combobox(input_grid, width=27, textvariable=self.pattern_var)
        self.pattern_input.grid(row=1, column=0, sticky="we", padx=(70, 10), pady=(5,0))
        self.pattern_input.config(values=self.search_history)
        self.pattern_input.bind("<<ComboboxSelected>>", self.perform_search)
        self.pattern_input.bind("<KeyRelease>", self.schedule_search)

        ttk.Label(input_grid, text="Ganti dgn:").grid(row=2, column=0, sticky="w", padx=(0, 10), pady=(5,0))
        self.replace_input = ttk.Entry(input_grid, width=30)
        self.replace_input.grid(row=2, column=0, sticky="we", padx=(70, 10), pady=(5,0))

        action_buttons_frame = ttk.Frame(main_frame)
        action_buttons_frame.pack(fill=tk.X, pady=(10, 15))
        self.search_button = ttk.Button(action_buttons_frame, text="Cari Pola", command=self.perform_search, style="TButton")
        self.search_button.pack(side="left", fill=tk.X, expand=True)
        self.clear_button = ttk.Button(action_buttons_frame, text="Bersihkan", command=self.clear_all, style="Nav.TButton")
        self.clear_button.pack(side="left", padx=(10, 0))
        self.replace_button = ttk.Button(action_buttons_frame, text="Ganti", command=self.replace_current, style="Nav.TButton", state="disabled")
        self.replace_button.pack(side="left", padx=(10, 0))
        self.replace_all_button = ttk.Button(action_buttons_frame, text="Ganti Semua", command=self.replace_all, style="Accent.TButton", state="disabled")
        self.replace_all_button.pack(side="left", padx=(5, 0))
        self.export_button = ttk.Button(action_buttons_frame, text="Export Hasil", command=self.export_results, style="Nav.TButton", state="disabled")
        self.export_button.pack(side="left", padx=(5, 0))
        case_sensitive_check = ttk.Checkbutton(action_buttons_frame, text="Case-Sensitive", variable=self.case_sensitive, command=self.schedule_search)
        case_sensitive_check.pack(side="left", padx=(10, 0))
        
        result_pane = tk.PanedWindow(main_frame, orient=tk.VERTICAL, sashrelief=tk.RAISED, bg=self.BG_COLOR)
        result_pane.pack(fill=tk.BOTH, expand=True)

        top_pane_frame = ttk.Frame(result_pane, height=250)
        top_pane_frame.rowconfigure(1, weight=1)
        top_pane_frame.columnconfigure(0, weight=1)
        result_header_frame = ttk.Frame(top_pane_frame)
        result_header_frame.grid(row=0, column=0, sticky="ew", pady=(0, 5))
        self.result_label = ttk.Label(result_header_frame, text="Hasil Pencarian:", font=("Segoe UI", 12, "bold"))
        self.result_label.pack(side="left", anchor="w")
        self.nav_prev_button = ttk.Button(result_header_frame, text="< Sebelumnya", style="Nav.TButton", command=self.navigate_previous, state="disabled")
        self.nav_prev_button.pack(side="right")
        self.nav_next_button = ttk.Button(result_header_frame, text="Berikutnya >", style="Nav.TButton", command=self.navigate_next, state="disabled")
        self.nav_next_button.pack(side="right", padx=(0, 5))
        self.result_text = tk.Text(top_pane_frame, height=10, width=80, state="disabled",
                                   bg=self.INPUT_BG_COLOR, fg=self.FG_COLOR,
                                   padx=10, pady=10, relief="flat", font=self.default_font, wrap="word")
        self.result_text.grid(row=1, column=0, sticky="nsew")
        result_pane.add(top_pane_frame)

        bottom_pane_frame = ttk.Frame(result_pane, height=100)
        bottom_pane_frame.rowconfigure(0, weight=1)
        bottom_pane_frame.columnconfigure(0, weight=1)
        list_scrollbar = ttk.Scrollbar(bottom_pane_frame, orient=tk.VERTICAL)
        self.match_listbox = tk.Listbox(bottom_pane_frame, bg=self.INPUT_BG_COLOR, fg=self.FG_COLOR,
                                        relief="flat", highlightthickness=0, font=("Consolas", 10),
                                        yscrollcommand=list_scrollbar.set)
        list_scrollbar.config(command=self.match_listbox.yview)
        self.match_listbox.grid(row=0, column=0, sticky="nsew")
        list_scrollbar.grid(row=0, column=1, sticky="ns")
        self.match_listbox.bind("<<ListboxSelect>>", self.on_match_select)
        result_pane.add(bottom_pane_frame)
        
        status_bar_frame = ttk.Frame(self.root, padding=(20, 5))
        status_bar_frame.pack(fill=tk.X, side=tk.BOTTOM)
        self.char_count_label = ttk.Label(status_bar_frame, text="Karakter: 0")
        self.char_count_label.pack(side=tk.RIGHT, padx=(0, 10))
        self.word_count_label = ttk.Label(status_bar_frame, text="Kata: 0")
        self.word_count_label.pack(side=tk.RIGHT, padx=(0, 20))
        
        self.result_text.tag_configure("highlight", background=self.HIGHLIGHT_COLOR, foreground="#000000")
        self.result_text.tag_configure("highlight_current", background=self.HIGHLIGHT_CURRENT_COLOR, foreground="#FFFFFF")
        self.update_status_bar()

    def schedule_search(self, event=None):
        if self.search_timer:
            self.root.after_cancel(self.search_timer)
        self.update_status_bar()
        if self.pattern_var.get().strip():
            self.search_timer = self.root.after(300, self.perform_search)
        else:
            self.search_timer = self.root.after(100, self.clear_results)

    def clear_results(self):
        self.found_indices = []
        self.current_match_index = -1
        self.result_text.config(state="normal")
        self.result_text.tag_remove("highlight", "1.0", tk.END)
        self.result_text.tag_remove("highlight_current", "1.0", tk.END)
        self.result_text.config(state="disabled")
        self.match_listbox.delete(0, tk.END)
        self.result_label.config(text="Hasil Pencarian:")
        self.update_nav_buttons_state()

    def clear_all(self):
        self.text_input.delete("1.0", tk.END)
        self.pattern_var.set("")
        self.replace_input.delete(0, tk.END)
        self.clear_results()
        self.update_status_bar()

    def update_status_bar(self, event=None):
        content = self.text_input.get("1.0", "end-1c")
        char_count = len(content)
        word_count = len(content.split())
        self.char_count_label.config(text=f"Karakter: {char_count}")
        self.word_count_label.config(text=f"Kata: {word_count}")

    def load_text_from_file(self):
        file_path = filedialog.askopenfilename(
            title="Pilih File Teks",
            filetypes=(("Document Files", "*.txt *.pdf *.docx"), ("All files", "*.*"))
        )
        if not file_path:
            return
        
        content, error = read_file_content(file_path)
        if error:
            self.result_label.config(text=f"Error: {error}")
            return

        if content is not None:
            self.text_input.delete("1.0", tk.END)
            self.text_input.insert("1.0", content)
            self.update_status_bar()
            self.result_label.config(text=f"Berhasil memuat: {os.path.basename(file_path)}")

    def perform_search(self, event=None):
        pola_saat_ini = self.pattern_var.get().strip()
        if pola_saat_ini and pola_saat_ini not in self.search_history:
            self.search_history.insert(0, pola_saat_ini)
            if len(self.search_history) > 10: self.search_history.pop()
            self.pattern_input.config(values=self.search_history)
            self.pattern_input.set(pola_saat_ini)

        self.clear_results()

        teks_original = self.text_input.get("1.0", tk.END).strip()
        pola_original = self.pattern_var.get().strip()

        if not teks_original or not pola_original:
            self.result_label.config(text="Hasil Pencarian: Teks dan Pola tidak boleh kosong.")
            return

        is_case_sensitive = self.case_sensitive.get()
        teks_cari = teks_original if is_case_sensitive else teks_original.lower()
        pola_cari = pola_original if is_case_sensitive else pola_original.lower()
        
        start_time = time.perf_counter()
        q_prime = 101
        self.found_indices = cari_pola(teks_cari, pola_cari, q_prime)
        end_time = time.perf_counter()
        self.search_duration = end_time - start_time

        self.result_text.config(state="normal")
        self.result_text.delete("1.0", tk.END)
        self.result_text.insert("1.0", teks_original)

        if self.found_indices:
            self.current_match_index = 0
            self.result_label.config(text=f"Hasil: Ditemukan {len(self.found_indices)} kali (dalam {self.search_duration:.4f} dtk).")
            
            pola_len = len(pola_original)
            for i, index in enumerate(self.found_indices):
                start_pos = f"1.0 + {index} chars"
                end_pos = f"1.0 + {index + pola_len} chars"
                self.result_text.tag_add("highlight", start_pos, end_pos)
                
                line, col = self.text_input.index(start_pos).split('.')
                snippet = self.text_input.get(f"{line}.0", f"{line}.end").strip()
                self.match_listbox.insert(tk.END, f"[{i+1:03d}] Baris {line}, Kol {col}: {snippet[:80]}")

            self.highlight_current_match(update_label=False)
        else:
            self.result_label.config(text=f"Hasil: Pola tidak ditemukan (dalam {self.search_duration:.4f} dtk).")
        
        self.result_text.config(state="disabled")
        self.update_nav_buttons_state()

    def highlight_current_match(self, update_label=True):
        if self.current_match_index < 0: return

        self.result_text.tag_remove("highlight_current", "1.0", tk.END)
        self.match_listbox.selection_clear(0, tk.END)
        self.match_listbox.itemconfig(self.current_match_index, {"bg": self.INPUT_BG_COLOR, "fg": self.FG_COLOR})

        pola_len = len(self.pattern_input.get())
        index = self.found_indices[self.current_match_index]
        start_pos = f"1.0 + {index} chars"
        
        self.result_text.tag_add("highlight_current", start_pos, f"{start_pos} + {pola_len} chars")
        self.result_text.see(start_pos)
        
        self.match_listbox.selection_set(self.current_match_index)
        self.match_listbox.activate(self.current_match_index)
        self.match_listbox.see(self.current_match_index)
        self.match_listbox.itemconfig(self.current_match_index, {"bg": self.ACCENT_COLOR, "fg": "#FFFFFF"})

        if update_label:
            total = len(self.found_indices)
            current_text = self.result_label.cget("text")
            duration_part = current_text[current_text.find("("):] if "(" in current_text else ""
            self.result_label.config(text=f"Hasil: Menampilkan {self.current_match_index + 1}/{total} {duration_part}")

    def navigate_next(self):
        if self.found_indices and self.current_match_index < len(self.found_indices) - 1:
            self.current_match_index += 1
            self.highlight_current_match()
            self.update_nav_buttons_state()

    def navigate_previous(self):
        if self.found_indices and self.current_match_index > 0:
            self.current_match_index -= 1
            self.highlight_current_match()
            self.update_nav_buttons_state()

    def update_nav_buttons_state(self):
        total = len(self.found_indices)
        has_matches = total > 0
        
        self.nav_prev_button.config(state="normal" if has_matches and self.current_match_index > 0 else "disabled")
        self.nav_next_button.config(state="normal" if has_matches and self.current_match_index < total - 1 else "disabled")
        self.replace_button.config(state="normal" if has_matches else "disabled")
        self.replace_all_button.config(state="normal" if has_matches else "disabled")
        self.export_button.config(state="normal" if has_matches else "disabled")

    def on_match_select(self, event):
        selection = self.match_listbox.curselection()
        if selection:
            selected_index = selection[0]
            if self.current_match_index != selected_index:
                self.current_match_index = selected_index
                self.highlight_current_match()
                self.update_nav_buttons_state()

    def replace_current(self):
        if self.current_match_index < 0: return

        replace_text = self.replace_input.get()
        pola_len = len(self.pattern_input.get())
        index = self.found_indices[self.current_match_index]

        start_pos = f"1.0 + {index} chars"
        end_pos = f"1.0 + {index + pola_len} chars"

        self.text_input.delete(start_pos, end_pos)
        self.text_input.insert(start_pos, replace_text)

        self.update_status_bar()
        self.perform_search()

    def replace_all(self):
        if not self.found_indices: return

        pola_original = self.pattern_input.get()
        replace_text = self.replace_input.get()
        teks_original = self.text_input.get("1.0", tk.END).strip()

        if self.case_sensitive.get():
            new_text = teks_original.replace(pola_original, replace_text)
        else:
            new_text = []
            last_index = 0
            for index in sorted(self.found_indices):
                new_text.append(teks_original[last_index:index])
                new_text.append(replace_text)
                last_index = index + len(pola_original)
            new_text.append(teks_original[last_index:])
            new_text = "".join(new_text)

        self.text_input.delete("1.0", tk.END)
        self.text_input.insert("1.0", new_text)

        self.update_status_bar()
        self.perform_search()

    def export_results(self):
        if not self.found_indices:
            self.result_label.config(text="Tidak ada hasil untuk diekspor.")
            return

        file_path = filedialog.asksaveasfilename(
            title="Simpan Hasil Pencarian",
            defaultextension=".txt",
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")],
            initialfile="hasil_pencarian.txt"
        )
        if not file_path: return

        try:
            with open(file_path, "w", encoding="utf-8") as f:
                f.write("="*50 + "\n" + "HASIL PENCARIAN RABIN-KARP".center(50) + "\n" + "="*50 + "\n\n")
                f.write(f"Pola Dicari: {self.pattern_var.get()}\n")
                f.write(f"Case-Sensitive: {'Ya' if self.case_sensitive.get() else 'Tidak'}\n")
                f.write(f"Waktu Pencarian: {self.search_duration:.6f} detik\n")
                f.write(f"Total Ditemukan: {len(self.found_indices)} kali\n\n" + "-"*50 + "\n\nLokasi Ditemukan:\n\n")

                for i, index in enumerate(self.found_indices):
                    line, col = self.text_input.index(f"1.0 + {index} chars").split('.')
                    line_text = self.text_input.get(f"{line}.0", f"{line}.end").strip()
                    f.write(f"{i+1:03d}. Baris {line}, Kolom {col}\n   Konteks: {line_text}\n\n")
            
            self.result_label.config(text=f"Hasil berhasil diekspor ke {os.path.basename(file_path)}")
        except Exception as e:
            self.result_label.config(text=f"Gagal mengekspor: {e}")

    def run(self):
        self.root.mainloop()

# ==============================================================================
# TITIK MASUK EKSEKUSI PROGRAM
# ==============================================================================

if __name__ == "__main__":
    app_root = tk.Tk()
    gui = RabinKarpGUI(app_root)
    gui.run()
