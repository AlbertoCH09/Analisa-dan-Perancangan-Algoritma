# ==============================================================================
# FUNGSI INTI ALGORITMA RABIN-KARP
# ==============================================================================

# Ukuran alfabet (misalnya, 256 untuk karakter ASCII)
d = 256

def cari_pola(teks, pola, q):
    """
    Fungsi untuk mencari semua kemunculan pola dalam teks menggunakan Algoritma Rabin-Karp.
    Parameter:
        teks (str): Teks utama tempat pencarian akan dilakukan.
        pola (str): Pola (string) yang akan dicari.
        q (int): Bilangan prima besar untuk operasi modulo pada hash.
    Mengembalikan:
        list: Daftar indeks awal di mana pola ditemukan dalam teks.
    """
    M = len(pola)
    N = len(teks)
    if M > N:
        return [] # Pola lebih panjang dari teks, tidak mungkin ditemukan

    p_hash = 0  # Nilai hash untuk pola
    t_hash = 0  # Nilai hash untuk jendela teks saat ini
    h = 1       # Nilai untuk perhitungan rolling hash

    # Hitung h = d^(M-1) % q
    # h digunakan untuk menghapus koefisien karakter terdepan saat menggeser jendela
    for _ in range(M - 1):
        h = (h * d) % q

    # Hitung nilai hash awal untuk pola dan jendela teks pertama (ukuran M)
    for i in range(M):
        p_hash = (d * p_hash + ord(pola[i])) % q
        t_hash = (d * t_hash + ord(teks[i])) % q

    hasil = [] # List untuk menyimpan indeks tempat pola ditemukan

    # Geser jendela (sliding window) di sepanjang teks
    for i in range(N - M + 1):
        # Jika nilai hash cocok, lakukan verifikasi karakter per karakter
        if p_hash == t_hash:
            cocok = True
            for j in range(M):
                if teks[i + j] != pola[j]:
                    cocok = False
                    break # Karakter tidak cocok, ini adalah kolisi hash
            if cocok:
                hasil.append(i) # Pola ditemukan pada indeks i

        # Hitung nilai hash untuk jendela berikutnya menggunakan teknik rolling hash
        # Hindari perhitungan ulang seluruh hash dari awal
        if i < N - M:
            t_hash = (d * (t_hash - ord(teks[i]) * h) + ord(teks[i + M])) % q
            # Pastikan t_hash tetap positif
            if t_hash < 0:
                t_hash = t_hash + q
    
    return hasil
