# PROJECT REQUIREMENT & PLAN (PRP)

## Gambaran Umum

Proyek ini berfokus pada studi dan implementasi **Algoritma String Matching**, dengan spesialisasi pada **Algoritma Rabin-Karp**. Tujuan utamanya adalah untuk memahami bagaimana algoritma ini dapat diterapkan sebagai solusi praktis untuk permasalahan pencarian kata dalam data teks yang umum ditemui dalam kehidupan sehari-hari.

## Permasalahan

Dalam aktivitas digital harian, kita sering kali perlu menemukan informasi spesifik di dalam kumpulan teks yang panjang. Contohnya termasuk:
- Mencari kata kunci tertentu dalam dokumen laporan atau file PDF.
- Menemukan sebuah istilah dalam artikel berita yang sedang dibaca.
- Mencari nama atau frasa dalam riwayat percakapan (chat).
- Memeriksa apakah sebuah _snippet_ kode ada di dalam sebuah file sumber.

Melakukan pencarian ini secara manual, terutama pada teks yang besar, sangat tidak efisien dan rentan terhadap kesalahan. Selain itu, penggunaan antarmuka berbasis konsol mungkin kurang intuitif bagi sebagian pengguna. Oleh karena itu, diperlukan sebuah metode komputasi yang cepat dan akurat untuk mengotomatisasi tugas ini, disajikan melalui antarmuka yang user-friendly.

## Tujuan Proyek

Tujuan dari proyek ini adalah:
1. Mempelajari konsep dasar dan cara kerja Algoritma Rabin-Karp sebagai salah satu solusi _exact string matching_.
2. Merancang dan membangun aplikasi antarmuka grafis (GUI) interaktif menggunakan Python untuk mengimplementasikan algoritma ini.
3. Mendemonstrasikan penerapan algoritma dalam studi kasus pencarian kata pada teks yang relevan dengan kehidupan sehari-hari.
4. Mengembangkan aplikasi GUI yang tidak hanya fungsional, tetapi juga memiliki fitur canggih seperti pencarian *real-time*, penggantian teks, dan ekspor hasil untuk menunjukkan penerapan praktis dalam skenario penggunaan modern.


## Batasan Masalah

Untuk menjaga fokus proyek, batasan masalah yang ditetapkan adalah sebagai berikut:
1. Algoritma yang dibahas dan diimplementasikan hanya **Algoritma Rabin-Karp**.
2. Pencarian bersifat **exact matching**, artinya pola yang dicari harus sama persis dengan teks yang ditemukan.
3. Implementasi program difokuskan pada sebuah **aplikasi antarmuka grafis (GUI)** yang kaya fitur.
4. Bahasa pemrograman yang digunakan adalah **Python**. Untuk implementasi inti algoritma **tanpa menggunakan pustaka eksternal pihak ketiga**, namun untuk GUI menggunakan **Tkinter** sebagai pustaka standar Python dan `pypdf`/`python-docx` untuk pembacaan file.
5. Konteks pengujian difokuskan pada pencarian kata dalam teks sederhana, dengan dukungan pembacaan dari file `.txt`, `.pdf`, dan `.docx`.

## Metode Penyelesaian

Proyek ini akan dilanjutkan melalui beberapa tahapan:
1. **Studi Literatur:** Mengumpulkan teori mengenai algoritma _string matching_ dan Rabin-Karp dari sumber-sumber tepercaya.
2. **Perancangan:** Mendesain alur kerja program GUI, _flowchart_, dan _pseudocode_ algoritma.
3. **Implementasi:** Menulis kode program Python sesuai dengan rancangan yang telah dibuat untuk aplikasi GUI.
4. **Pengujian:** Menguji program dengan studi kasus pencarian kata pada sampel teks (misalnya, paragraf dari artikel) dan berbagai format file.


## Tools yang Digunakan

- **Bahasa Pemrograman:** Python 3.x
- **Teks Editor / IDE:** Visual Studio Code (atau sejenisnya)
- **Sistem Operasi:** Windows/Linux/macOS