# TODO - Checklist Proyek Laporan & Implementasi

Berikut adalah daftar periksa dari semua artefak yang telah dibuat untuk proyek laporan dan implementasi Algoritma Rabin-Karp.

### Tahap 1: Dokumentasi Proyek
- [x] Buat struktur folder proyek.
- [x] Buat file `PRP.md` (Project Requirement & Plan).
- [x] Buat file `README.md` sebagai panduan proyek.
- [x] Buat file `TODO.md` ini sebagai checklist penyelesaian.

### Tahap 2: Implementasi Program



#### Versi Antarmuka Grafis (GUI) - `src/main.py`
- [x] Buat kerangka dasar aplikasi GUI dengan Tkinter.
- [x] Implementasikan fungsi inti Algoritma Rabin-Karp.
- [x] Desain antarmuka dengan tema futuristik (warna gelap, font modern).
- [x] Tambahkan fitur untuk memuat teks dari file (`.txt`, `.pdf`, `.docx`).
- [x] Tambahkan fitur sorot (highlight) untuk semua hasil yang ditemukan.
- [x] **[Fitur Lanjutan]** Implementasikan pencarian *real-time* (saat mengetik).
- [x] **[Fitur Lanjutan]** Tambahkan riwayat pencarian pada input pola (`Combobox`).
- [x] **[Fitur Lanjutan]** Tambahkan opsi pencarian *case-sensitive*.
- [x] **[Fitur Lanjutan]** Tambahkan fungsi "Ganti" dan "Ganti Semua".
- [x] **[Fitur Lanjutan]** Tambahkan tombol navigasi untuk berpindah antar hasil.
- [x] **[Fitur Lanjutan]** Tampilkan daftar hasil di `Listbox` beserta konteksnya.
- [x] **[Fitur Lanjutan]** Implementasikan fungsi "Ekspor Hasil" ke file `.txt`.
- [x] **[Fitur Lanjutan]** Buat status bar yang menampilkan jumlah kata dan karakter.
- [x] **[Perbaikan Bug]** Perbaiki bug di mana status bar tidak update setelah memuat file atau mengganti teks.

#### Manajemen Dependensi
- [x] Buat file `requirements.txt` yang berisi daftar dependensi eksternal proyek.

### Tahap 3: Finalisasi
- [x] Revisi `PRP.md` dan `TODO.md` agar sesuai dengan fungsionalitas program GUI yang ada.
